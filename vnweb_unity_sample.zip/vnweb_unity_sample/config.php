<?php

/*==========================*/
// Connect to db
/*==========================*/
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vidyanusa_db";

?>